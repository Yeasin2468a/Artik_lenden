# ফোনে APK বানানোর সবচেয়ে সহজ পদ্ধতি

এই project-এ GitHub Actions workflow দেওয়া আছে। GitHub-এর server-এই Flutter/Android build হবে; ফোনে Flutter install করতে হবে না।

## 1) GitHub-এ project upload

- GitHub-এ নতুন একটি **private repository** তৈরি করুন, যেমন `arthik-lenden`।
- এই ZIP extract করে ভেতরের `arthik_lenden` folder-এর **সব ফাইল** repository-তে upload করুন।
- নিশ্চিত করুন `.github/workflows/build-apk.yml` ফাইলটিও upload হয়েছে।
- `main` branch-এ commit করুন।

## 2) APK build চালান

Repository → **Actions** → **Build Android APK** → **Run workflow** → `main` → **Run workflow`.

Workflow শেষ হলে green check দেখাবে। Run-এর ভিতরে নিচে **Artifacts** অংশে `arthik-lenden-apk` থাকবে। সেটি download করলে ZIP পাওয়া যাবে; ZIP খুলে `app-release.apk` ফোনে install করা যাবে।

GitHub Actions-এর artifact workflow শেষ হওয়ার পর build output সংরক্ষণ ও download করার জন্যই ব্যবহৃত হয়।

## 3) পরে নতুন APK

Code-এ পরিবর্তন করে `main`-এ commit/push করলেই workflow আবার চলবে। চাইলে Actions থেকে **Run workflow** দিয়েও manually build করা যাবে।

## গুরুত্বপূর্ণ

- এটি debug APK নয়; release APK।
- Play Store-এর জন্য পরে আলাদা signing/release setup দরকার হবে।
- বর্তমান project-এ Android native folder source-এ রাখা হয়নি; workflow build server-এ `flutter create` দিয়ে Android/Web folder তৈরি করে, তারপর APK build করে।
