# আর্থিক লেনদেন — Android + Web

Supplied screenshots-এর visual reference ধরে তৈরি একটি Flutter starter app। এটি **UI-only mock নয়**: Bottom navigation, party/account/item CRUD, transaction entry, search, swipe-to-delete, reports এবং local persistence যুক্ত আছে।

## চালানোর জন্য

1. Flutter SDK 3.22+ ইনস্টল করুন।
2. project folder-এ `flutter pub get` চালান।
3. Android: `flutter run` বা `flutter build apk --release`
4. Web: `flutter run -d chrome` বা `flutter build web --release`

## গুরুত্বপূর্ণ

- ডেটা `shared_preferences`-এ লোকালি থাকে।
- Production app-এর জন্য login, cloud database/sync, permissions, audit log, invoice PDF, real backup এবং secure authentication আলাদা করে যোগ করা উচিত।
- Screenshot-এর বাংলা font/spacing যতটা সম্ভব কাছাকাছি রাখা হয়েছে; প্রকল্পে কোনো copyrighted brand asset ব্যবহার করা হয়নি।
